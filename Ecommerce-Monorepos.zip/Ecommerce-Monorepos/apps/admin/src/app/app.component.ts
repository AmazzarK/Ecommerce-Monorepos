import { Component } from "@angular/core";

@Component({
  selector: "ahlamcoding-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
})
export class AppComponent {
  title = "admin";
}
